# Task 10 — Search Bar, Category Filters & Daily Learning Reminder

Built independently with mock/static data per the team plan — no dependency
on Task 5/6/7 (auth/backend) to preview or test this.

## Files

```
lib/
  models/
    mock_data.dart            # Static lessons + categories, mock fetchers
  widgets/
    search_bar_widget.dart    # Debounced search input (AppSearchBar)
    category_filters.dart     # Horizontal chip filter row (CategoryFilters)
    daily_reminder_widget.dart# Toggle + time picker (DailyReminderWidget)
  screens/
    task10_demo_screen.dart   # Wires all 3 together + filters lesson list
  main.dart                   # Standalone entry point for preview
```

## Run standalone

```
flutter run -t lib/main.dart
```

## Merging into the main app

Drop the three files in `lib/widgets/` into the shared repo's widgets
folder, then either:
- Add `Task10DemoScreen` as a tab/route directly, or
- Pull `AppSearchBar`, `CategoryFilters`, and `DailyReminderWidget` into
  the real Home/Explore screens (Task 2 / Task 4) individually — each
  widget is self-contained and takes plain callbacks, so no shared state
  management is required to drop them in.

## Swapping mock data for live APIs (later, Task 6/7)

`mock_data.dart` exposes `fetchLessons()` and `fetchCategories()` as
`Future`-returning functions with the exact shape a real API call would
return. Once the backend is live, replace their internals with HTTP calls
— no changes needed in the screen or widgets.

## Wiring real notifications (later)

`DailyReminderWidget` currently just tracks on/off + time in local state
via `onChanged`. To make it actually fire notifications:

1. Add `flutter_local_notifications` to `pubspec.yaml`.
2. In the `onChanged` callback (see commented example at the bottom of
   `daily_reminder_widget.dart`), call your scheduling helper when
   `enabled == true`, and cancel it when `false`.

This may overlap with Task 9's local storage work if reminder preference
should persist across app restarts (store `ReminderSettings` via
Hive/Sqflite) — worth a quick sync with Goodwill so you don't duplicate
storage setup.
