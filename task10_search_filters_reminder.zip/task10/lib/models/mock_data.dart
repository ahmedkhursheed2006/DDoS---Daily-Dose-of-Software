// mock_data.dart
// Static/mock data so UI can be built and tested without live APIs.
// Replace `fetchLessons()` / `fetchCategories()` with real API calls
// once Task 6/7 backend endpoints are live — keep the same return
// shapes (List<Lesson>, List<String>) so no UI code needs to change.

class Lesson {
  final String id;
  final String title;
  final String category;
  final String summary;

  const Lesson({
    required this.id,
    required this.title,
    required this.category,
    required this.summary,
  });
}

const List<String> mockCategories = [
  'All',
  'Grammar',
  'Vocabulary',
  'Speaking',
  'Listening',
  'Writing',
  'Idioms',
];

const List<Lesson> mockLessons = [
  Lesson(
    id: 'l1',
    title: 'Present Perfect vs Simple Past',
    category: 'Grammar',
    summary: 'Learn when to use each tense with real examples.',
  ),
  Lesson(
    id: 'l2',
    title: '20 Everyday Idioms',
    category: 'Idioms',
    summary: 'Common idioms you will hear in daily conversation.',
  ),
  Lesson(
    id: 'l3',
    title: 'Describing People',
    category: 'Vocabulary',
    summary: 'Adjectives and phrases to describe appearance and personality.',
  ),
  Lesson(
    id: 'l4',
    title: 'Ordering Food at a Restaurant',
    category: 'Speaking',
    summary: 'Practice dialogues for ordering and making requests politely.',
  ),
  Lesson(
    id: 'l5',
    title: 'Understanding Fast Speech',
    category: 'Listening',
    summary: 'Tips for catching reduced sounds and linking in spoken English.',
  ),
  Lesson(
    id: 'l6',
    title: 'Writing a Formal Email',
    category: 'Writing',
    summary: 'Structure, tone, and common phrases for professional emails.',
  ),
  Lesson(
    id: 'l7',
    title: 'Phrasal Verbs with Get',
    category: 'Grammar',
    summary: 'Get up, get over, get along — meanings and usage.',
  ),
  Lesson(
    id: 'l8',
    title: 'Small Talk Starters',
    category: 'Speaking',
    summary: 'Break the ice naturally in casual conversations.',
  ),
];

// Mock async fetchers — swap internals for real API calls later,
// keep signatures identical so callers don't need to change.
Future<List<Lesson>> fetchLessons() async {
  await Future.delayed(const Duration(milliseconds: 200));
  return mockLessons;
}

Future<List<String>> fetchCategories() async {
  await Future.delayed(const Duration(milliseconds: 100));
  return mockCategories;
}
