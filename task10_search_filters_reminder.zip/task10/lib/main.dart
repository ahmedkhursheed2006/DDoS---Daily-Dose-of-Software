// main.dart
// Standalone runner for previewing Task 10 in isolation.
// If merging into the main app, you likely won't need this file —
// just add Task10DemoScreen as a route/tab instead.

import 'package:flutter/material.dart';
import 'screens/task10_demo_screen.dart';

void main() {
  runApp(const Task10PreviewApp());
}

class Task10PreviewApp extends StatelessWidget {
  const Task10PreviewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Task 10 Preview',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const Task10DemoScreen(),
    );
  }
}
